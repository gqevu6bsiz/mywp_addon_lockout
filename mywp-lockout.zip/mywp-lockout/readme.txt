=== My WP Add-on Lockout ===
Contributors: gqevu6bsiz
Donate link: http://gqevu6bsiz.chicappa.jp
Tags:
Requires at least: 4.7
Tested up to: 6.3
Stable tag: 1.10.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
